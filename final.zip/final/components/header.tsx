import styles from '../styles/header.module.css';

export default function header() {
    const redirect = () => {
        window.location.href = "upload"
    }
    const redirectScarves = () => {
        window.location.href = "scarves"
    }
    const redirectAbout = () => {
        window.location.href = "about"
    }
    return (
        <div className={styles.wrapper}>
            <div className={styles.grid}>
                <h5></h5>
            </div>
            <div className={styles.grid}>
                <h5 onClick={redirect}>Upload</h5>
            </div>
            <div className={styles.grid}>
                <h5 onClick={redirectScarves}>Scarves</h5>
            </div>
            <div className={styles.grid}>
                <h5 onClick={redirectAbout}>About Us</h5>
            </div>
            <div className={styles.grid}>
                
            </div>
        </div>
    )
}