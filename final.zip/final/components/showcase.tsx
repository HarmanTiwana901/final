import styles from '../styles/showcase.module.css';

export default function showcase(props) {

    return (
        <div className={styles.wrapper}>
            <div className={styles.left}>
                <img height="400px" src="https://i.imgur.com/VIy9S2k.jpg"/>
            </div>
            <div className={styles.right}>
                <h3>{props.showcaseItem[0].name}</h3>
                <h6>{props.showcaseItem[0].curses}</h6>
                <p>{props.showcaseItem[0].description}</p>
            </div>
        </div>
    )
}


