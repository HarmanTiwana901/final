import type { NextPage } from 'next'
import Header from '../components/header';
import Showcase from '../components/showcase';
import { useState } from 'react';
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import { MongoClient } from "mongodb";

const Home: NextPage = (props) => {
  
  return (
    <div className={styles.container}>
     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eu odio sit amet felis semper ullamcorper. Nulla tincidunt blandit quam tincidunt hendrerit. Cras in turpis id diam sagittis dictum malesuada eu augue. Maecenas sit amet ligula laoreet, fermentum lorem eu, tempor dui. Curabitur tristique odio sed nisi malesuada congue. Aliquam ac convallis mi. Fusce sit amet purus pulvinar, euismod metus ac, rhoncus dui. Nulla id venenatis massa. Aliquam ante quam, rutrum ut lacinia vitae, bibendum at nisl.</p>
    </div>
  )
}


export default Home
