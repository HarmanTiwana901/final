import type { NextPage } from 'next'
import Header from '../components/header';
import Showcase from '../components/showcase';
import { useState } from 'react';
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import { MongoClient } from "mongodb";

const Home: NextPage = (props) => {
  
  return (
    <div className={styles.container}>
      <Header/>
      <Showcase showcaseItem={props.data}/>
      <div className={styles.grid}>
      {props.data.map((data) => (   // note the removed {}
      
          <div className={styles.card}>
            <h3>{data.name}</h3>
            <h5>{data.curses}</h5>
            <p>{data.description}</p>
          
          </div>
      
    ))}
    </div>
    </div>
  )
}

export async function getStaticProps() {
  const client = await MongoClient.connect("mongodb+srv://harman:manwar123@cluster0.u6rwi.mongodb.net/scarf?retryWrites=true&w=majority")
  const db = client.db();
  const collection = db.collection("scarfs");
  
  const yourData = await collection.find({}, {}).toArray();
  JSON.stringify(yourData);
  client.close();
  return {
    props: {
      data: JSON.parse(JSON.stringify(yourData))
    } 
  }
}

export default Home
