import type { NextPage } from 'next'
import { MongoClient } from 'mongodb';
import { responsiveProperty } from '@mui/material/styles/cssUtils';
const Home: NextPage = () => {

  return (
    <div>
      <input type="text" placeholder="Name"></input>
      <br/>
      <input type="text" placeholder="Curses"></input>
      <br/>
      <input type="text" placeholder="Description"></input>
      <button type="button">Add</button>
    </div>
  )
}
export default Home
