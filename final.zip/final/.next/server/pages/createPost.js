"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/createPost";
exports.ids = ["pages/createPost"];
exports.modules = {

/***/ "./pages/createPost.tsx":
/*!******************************!*\
  !*** ./pages/createPost.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    const data = req.body;\n    const client = await mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient.connect(\"mongodb+srv://harman:manwar123@cluster0.u6rwi.mongodb.net/scarf?retryWrites=true&w=majority\");\n    const db = client.db();\n    const collection = db.collection(\"scarfs\");\n    const yourData = await collection.find({\n    }, {\n    }).toArray();\n    const result = await collection.insertOne(data);\n    console.log(result);\n    client.close();\n    res.status(201).json({\n        message: \"Success\"\n    });\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9jcmVhdGVQb3N0LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBcUM7QUFFdEIsZUFBZUMsT0FBTyxDQUFDQyxHQUFHLEVBQUVDLEdBQUcsRUFBRSxDQUFDO0lBQzdDLEtBQUssQ0FBQ0MsSUFBSSxHQUFHRixHQUFHLENBQUNHLElBQUk7SUFFakIsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDTix3REFBbUIsQ0FBQyxDQUE2RjtJQUN0SSxLQUFLLENBQUNRLEVBQUUsR0FBR0YsTUFBTSxDQUFDRSxFQUFFO0lBQ3BCLEtBQUssQ0FBQ0MsVUFBVSxHQUFHRCxFQUFFLENBQUNDLFVBQVUsQ0FBQyxDQUFRO0lBSXpDLEtBQUssQ0FBQ0MsUUFBUSxHQUFHLEtBQUssQ0FBQ0QsVUFBVSxDQUFDRSxJQUFJLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBRSxDQUFDO0lBQUEsQ0FBQyxFQUFFQyxPQUFPO0lBQ3RELEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEtBQUssQ0FBQ0osVUFBVSxDQUFDSyxTQUFTLENBQUNWLElBQUk7SUFDOUNXLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxNQUFNO0lBQ2xCUCxNQUFNLENBQUNXLEtBQUs7SUFFWmQsR0FBRyxDQUFDZSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUMsQ0FBQztRQUFDQyxPQUFPLEVBQUUsQ0FBUztJQUFDLENBQUM7QUFHbkQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2ZpbmFsLy4vcGFnZXMvY3JlYXRlUG9zdC50c3g/MjZiNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gXCJtb25nb2RiXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVxLmJvZHk7XHJcblxyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QoXCJtb25nb2RiK3NydjovL2hhcm1hbjptYW53YXIxMjNAY2x1c3RlcjAudTZyd2kubW9uZ29kYi5uZXQvc2NhcmY/cmV0cnlXcml0ZXM9dHJ1ZSZ3PW1ham9yaXR5XCIpXHJcbiAgICAgICAgY29uc3QgZGIgPSBjbGllbnQuZGIoKTtcclxuICAgICAgICBjb25zdCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihcInNjYXJmc1wiKTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgXHJcbiAgICAgICAgY29uc3QgeW91ckRhdGEgPSBhd2FpdCBjb2xsZWN0aW9uLmZpbmQoe30sIHt9KS50b0FycmF5KCk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5pbnNlcnRPbmUoZGF0YSk7XHJcbiAgICAgICAgY29uc29sZS5sb2cocmVzdWx0KTtcclxuICAgICAgICBjbGllbnQuY2xvc2UoKTtcclxuXHJcbiAgICAgICAgcmVzLnN0YXR1cygyMDEpLmpzb24oeyBtZXNzYWdlOiBcIlN1Y2Nlc3NcIiB9KTtcclxuXHJcbiAgICBcclxufTsiXSwibmFtZXMiOlsiTW9uZ29DbGllbnQiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiZGF0YSIsImJvZHkiLCJjbGllbnQiLCJjb25uZWN0IiwiZGIiLCJjb2xsZWN0aW9uIiwieW91ckRhdGEiLCJmaW5kIiwidG9BcnJheSIsInJlc3VsdCIsImluc2VydE9uZSIsImNvbnNvbGUiLCJsb2ciLCJjbG9zZSIsInN0YXR1cyIsImpzb24iLCJtZXNzYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/createPost.tsx\n");

/***/ }),

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/createPost.tsx"));
module.exports = __webpack_exports__;

})();