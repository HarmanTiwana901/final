/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/about";
exports.ids = ["pages/about"];
exports.modules = {

/***/ "./styles/Home.module.css":
/*!********************************!*\
  !*** ./styles/Home.module.css ***!
  \********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"Home_container__bCOhY\",\n\t\"card\": \"Home_card___LpL1\",\n\t\"grid\": \"Home_grid__GxQ85\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL2ZpbmFsLy4vc3R5bGVzL0hvbWUubW9kdWxlLmNzcz83MTI3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImNvbnRhaW5lclwiOiBcIkhvbWVfY29udGFpbmVyX19iQ09oWVwiLFxuXHRcImNhcmRcIjogXCJIb21lX2NhcmRfX19McEwxXCIsXG5cdFwiZ3JpZFwiOiBcIkhvbWVfZ3JpZF9fR3hRODVcIlxufTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./styles/Home.module.css\n");

/***/ }),

/***/ "./pages/about.tsx":
/*!*************************!*\
  !*** ./pages/about.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/Home.module.css */ \"./styles/Home.module.css\");\n/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Home = (props)=>{\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"div\", {\n        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_1___default().container),\n        __source: {\n            fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\about.tsx\",\n            lineNumber: 13,\n            columnNumber: 5\n        },\n        __self: undefined,\n        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"p\", {\n            __source: {\n                fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\about.tsx\",\n                lineNumber: 14,\n                columnNumber: 6\n            },\n            __self: undefined,\n            children: \"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eu odio sit amet felis semper ullamcorper. Nulla tincidunt blandit quam tincidunt hendrerit. Cras in turpis id diam sagittis dictum malesuada eu augue. Maecenas sit amet ligula laoreet, fermentum lorem eu, tempor dui. Curabitur tristique odio sed nisi malesuada congue. Aliquam ac convallis mi. Fusce sit amet purus pulvinar, euismod metus ac, rhoncus dui. Nulla id venenatis massa. Aliquam ante quam, rutrum ut lacinia vitae, bibendum at nisl.\"\n        })\n    }));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hYm91dC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBTThDO0FBRzlDLEtBQUssQ0FBQ0MsSUFBSSxJQUFjQyxLQUFLLEdBQUssQ0FBQztJQUVqQyxNQUFNLHNFQUNIQyxDQUFHO1FBQUNDLFNBQVMsRUFBRUosMEVBQWdCOzs7Ozs7O3VGQUM5Qk0sQ0FBQzs7Ozs7OztzQkFBQyxDQUE0Zjs7O0FBR3BnQixDQUFDO0FBR0QsaUVBQWVMLElBQUkiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9maW5hbC8uL3BhZ2VzL2Fib3V0LnRzeD81OTllIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dFBhZ2UgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uL2NvbXBvbmVudHMvaGVhZGVyJztcclxuaW1wb3J0IFNob3djYXNlIGZyb20gJy4uL2NvbXBvbmVudHMvc2hvd2Nhc2UnO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSdcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzJ1xyXG5pbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gXCJtb25nb2RiXCI7XHJcblxyXG5jb25zdCBIb21lOiBOZXh0UGFnZSA9IChwcm9wcykgPT4ge1xyXG4gIFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XHJcbiAgICAgPHA+TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gQWVuZWFuIGV1IG9kaW8gc2l0IGFtZXQgZmVsaXMgc2VtcGVyIHVsbGFtY29ycGVyLiBOdWxsYSB0aW5jaWR1bnQgYmxhbmRpdCBxdWFtIHRpbmNpZHVudCBoZW5kcmVyaXQuIENyYXMgaW4gdHVycGlzIGlkIGRpYW0gc2FnaXR0aXMgZGljdHVtIG1hbGVzdWFkYSBldSBhdWd1ZS4gTWFlY2VuYXMgc2l0IGFtZXQgbGlndWxhIGxhb3JlZXQsIGZlcm1lbnR1bSBsb3JlbSBldSwgdGVtcG9yIGR1aS4gQ3VyYWJpdHVyIHRyaXN0aXF1ZSBvZGlvIHNlZCBuaXNpIG1hbGVzdWFkYSBjb25ndWUuIEFsaXF1YW0gYWMgY29udmFsbGlzIG1pLiBGdXNjZSBzaXQgYW1ldCBwdXJ1cyBwdWx2aW5hciwgZXVpc21vZCBtZXR1cyBhYywgcmhvbmN1cyBkdWkuIE51bGxhIGlkIHZlbmVuYXRpcyBtYXNzYS4gQWxpcXVhbSBhbnRlIHF1YW0sIHJ1dHJ1bSB1dCBsYWNpbmlhIHZpdGFlLCBiaWJlbmR1bSBhdCBuaXNsLjwvcD5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhvbWVcclxuIl0sIm5hbWVzIjpbInN0eWxlcyIsIkhvbWUiLCJwcm9wcyIsImRpdiIsImNsYXNzTmFtZSIsImNvbnRhaW5lciIsInAiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/about.tsx\n");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/about.tsx"));
module.exports = __webpack_exports__;

})();