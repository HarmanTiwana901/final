"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/upload";
exports.ids = ["pages/upload"];
exports.modules = {

/***/ "./pages/upload.tsx":
/*!**************************!*\
  !*** ./pages/upload.tsx ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Home = ()=>{\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(\"div\", {\n        __source: {\n            fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n            lineNumber: 7,\n            columnNumber: 5\n        },\n        __self: undefined,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"input\", {\n                type: \"text\",\n                placeholder: \"Name\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 8,\n                    columnNumber: 7\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"br\", {\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 9,\n                    columnNumber: 7\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"input\", {\n                type: \"text\",\n                placeholder: \"Curses\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 10,\n                    columnNumber: 7\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"br\", {\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 11,\n                    columnNumber: 7\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"input\", {\n                type: \"text\",\n                placeholder: \"Description\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 12,\n                    columnNumber: 7\n                },\n                __self: undefined\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"button\", {\n                type: \"button\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\harma\\\\OneDrive\\\\Desktop\\\\2107final\\\\final\\\\pages\\\\upload.tsx\",\n                    lineNumber: 13,\n                    columnNumber: 7\n                },\n                __self: undefined,\n                children: \"Add\"\n            })\n        ]\n    }));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy91cGxvYWQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFHQSxLQUFLLENBQUNBLElBQUksT0FBbUIsQ0FBQztJQUU1QixNQUFNLHVFQUNIQyxDQUFHOzs7Ozs7OztpRkFDREMsQ0FBSztnQkFBQ0MsSUFBSSxFQUFDLENBQU07Z0JBQUNDLFdBQVcsRUFBQyxDQUFNOzs7Ozs7OztpRkFDcENDLENBQUU7Ozs7Ozs7O2lGQUNGSCxDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBTTtnQkFBQ0MsV0FBVyxFQUFDLENBQVE7Ozs7Ozs7O2lGQUN0Q0MsQ0FBRTs7Ozs7Ozs7aUZBQ0ZILENBQUs7Z0JBQUNDLElBQUksRUFBQyxDQUFNO2dCQUFDQyxXQUFXLEVBQUMsQ0FBYTs7Ozs7Ozs7aUZBQzNDRSxDQUFNO2dCQUFDSCxJQUFJLEVBQUMsQ0FBUTs7Ozs7OzswQkFBQyxDQUFHOzs7O0FBRy9CLENBQUM7QUFDRCxpRUFBZUgsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL2ZpbmFsLy4vcGFnZXMvdXBsb2FkLnRzeD8zYThmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dFBhZ2UgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xyXG5pbXBvcnQgeyByZXNwb25zaXZlUHJvcGVydHkgfSBmcm9tICdAbXVpL21hdGVyaWFsL3N0eWxlcy9jc3NVdGlscyc7XHJcbmNvbnN0IEhvbWU6IE5leHRQYWdlID0gKCkgPT4ge1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOYW1lXCI+PC9pbnB1dD5cclxuICAgICAgPGJyLz5cclxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJDdXJzZXNcIj48L2lucHV0PlxyXG4gICAgICA8YnIvPlxyXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkRlc2NyaXB0aW9uXCI+PC9pbnB1dD5cclxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCI+QWRkPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgSG9tZVxyXG4iXSwibmFtZXMiOlsiSG9tZSIsImRpdiIsImlucHV0IiwidHlwZSIsInBsYWNlaG9sZGVyIiwiYnIiLCJidXR0b24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/upload.tsx\n");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/upload.tsx"));
module.exports = __webpack_exports__;

})();